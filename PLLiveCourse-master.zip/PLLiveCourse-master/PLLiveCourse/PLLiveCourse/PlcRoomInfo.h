//
//  PlcRoomInfo.h
//  PLLiveCourse
//
//  Created by TaoZeyu on 16/8/2.
//  Copyright © 2016年 com.pili-engineering. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlcRoomInfo : NSObject

@property (nonatomic, strong) NSString *roomName;
@property (nonatomic, strong) NSString *playableURL;

@end
