//
//  PlcRoomInfo.m
//  PLLiveCourse
//
//  Created by TaoZeyu on 16/8/2.
//  Copyright © 2016年 com.pili-engineering. All rights reserved.
//

#import "PlcRoomInfo.h"

@implementation PlcRoomInfo

@end
