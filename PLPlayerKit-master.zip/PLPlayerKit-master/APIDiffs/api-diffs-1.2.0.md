# PLPlayerKit 1.1.2 to 1.2.0 API Differences

## General Headers

- *Added* Class `VideoPlayerViewController`
- *Added* Header `PLPlayerTypeDefines.h`
