# PLPlayerKit 1.2.0 to 1.2.1 API Differences

## General Headers

- *Removed* `VideoPlayerViewController.h`
- *Modified* `PLPlayerTypeDefines.h`
	- *Added* `PLPlayerErrorDomain`
	- *Added* `PLPlayerError`
- *Modified* `PLVideoPlayerController.h`
	- *Added* `PLVideoPlayerControllerDelegate`
