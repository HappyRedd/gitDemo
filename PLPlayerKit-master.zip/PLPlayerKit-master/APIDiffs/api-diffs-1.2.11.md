# PLPlayerKit 1.2.10 to 1.2.11 API Differences

## General Headers

None