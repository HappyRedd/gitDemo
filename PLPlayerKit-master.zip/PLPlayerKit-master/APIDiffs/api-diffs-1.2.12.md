# PLPlayerKit 1.2.11 to 1.2.12 API Differences

## General Headers

None