# PLPlayerKit 1.2.13 to 1.2.14 API Differences

## General Headers

```
PLAudioManager.h
```
- *Added* class `PLAudioManager`
