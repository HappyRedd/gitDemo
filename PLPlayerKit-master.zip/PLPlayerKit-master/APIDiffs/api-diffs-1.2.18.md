# PLPlayerKit 1.2.17 to 1.2.18 API Differences

## General Headers

None