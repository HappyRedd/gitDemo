# PLPlayerKit 1.2.18 to 1.2.19 API Differences

## General Headers

None