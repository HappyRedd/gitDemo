# PLPlayerKit 1.2.1 to 1.2.2 API Differences

## General Headers

None