# PLPlayerKit 1.2.19 to 1.2.20 API Differences

## General Headers

```
PLPlayerTypeDefines.h
```
- *Modified* PLPlayerState
    - *Added* PLPlayerStateSeeking
