# PLPlayerKit 1.2.20 to 1.2.21 API Differences

## General Headers

None