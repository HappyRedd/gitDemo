# PLPlayerKit 1.2.21 to 1.2.22 API Differences

## General Headers

None