# PLPlayerKit 1.2.3 to 1.2.4 API Differences

## General Headers

```
PLPlayerTypeDefines.h
```
- *Add* `extern NSString * const PLMovieParameterFrameViewContentMode;`
