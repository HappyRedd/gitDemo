# PLPlayerKit 1.2.8 to 1.2.9 API Differences

## General Headers

```
PLPlayerTypeDefines.h
```
- *Add* type ```PLVideoPlayerBackgroundMode```
```
PLVideoPlayerController.h
```
- *Add* property ```@property (nonatomic, assign) PLVideoPlayerBackgroundMode   backgroundMode;```
