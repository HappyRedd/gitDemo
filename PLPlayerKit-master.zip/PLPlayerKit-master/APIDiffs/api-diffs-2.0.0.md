# PLPlayerKit 1.2.19 to 2.0.0 API Differences

## General Headers

```
PLPlayer.h
```

- *Added* Class `PLPlayer`
    - *Added* Type `PLPlayerStatus`
    - *Added* Protocol `PLPlayerDelegate`
- *Removed* Class `PLVideoPlayerController`
- *Removed* Class `PLAudioPlayerController`
