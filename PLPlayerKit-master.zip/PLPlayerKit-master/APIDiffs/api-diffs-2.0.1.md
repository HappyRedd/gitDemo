# PLPlayerKit 2.0.0 to 2.0.1 API Differences

## General Headers

None