# PLPlayerKit 2.0.1 to 2.0.2 API Differences

## General Headers

```
PLPlayer.h
```
- *Added* `@property (nonatomic, assign) NSTimeInterval    timeoutIntervalForMediaPackets;`
