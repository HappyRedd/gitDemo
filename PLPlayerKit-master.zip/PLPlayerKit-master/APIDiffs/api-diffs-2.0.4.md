# PLPlayerKit 2.0.3 to 2.0.4 API Differences

## General Headers

None