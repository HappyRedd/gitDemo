# PLPlayerKit 2.1.2 to 2.1.3 API Differences

## General Headers


```
PLPlayerOption.h
```
- *Added* `extern NSString  * _Nonnull PLPlayerOptionKeyMaxL1BufferDuration;`
- *Added* `extern NSString  * _Nonnull PLPlayerOptionKeyMaxL2BufferDuration;`

