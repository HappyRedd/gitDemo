# PLPlayerKit 2.1.3 to 2.2.0 API Differences

## General Headers
