# PLPlayerKit 2.2.0 to 2.2.1 API Differences

## General Headers

```
PLPlayerOption.h
```
- *Added* `NS_ENUM(NSInteger, PLLogLevel)`
- *Added* `extern NSString  * _Nonnull PLPlayerOptionKeyLogLevel;`
- *Added* `extern NSString  * _Nonnull PLPlayerOptionKeyDNSManager;`