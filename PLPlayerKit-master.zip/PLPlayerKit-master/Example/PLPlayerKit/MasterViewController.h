//
//  MasterViewController.h
//  PLPlayerKitDemo
//
//  Created by 0day on 14/11/13.
//  Copyright (c) 2014年 qgenius. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController

@end