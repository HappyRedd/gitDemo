<?php

class MemberAction extends CommonAction {

    public function index() {
        $this->display();
    }


}