<?php

class NewsAction extends CommonAction {

    public function index() {
//            die(".............");
        $M = M("News");
//        die(".............");
        $count = $M->count();
        import("ORG.Util.Page");       //载入分页类
        $page = new Page($count, 20);
        $showPage = $page->show();
        $this->assign("page", $showPage);
        $this->assign("list", D("News")->listNews($page->firstRow, $page->listRows));
        $this->display();
    }

    public function category() {
        if (IS_POST) {
            echo json_encode(D("News")->category());
        } else {
        	$this->assign("list", D("News")->category());
            $this->display();
        }
    }

    public function add() {
        if (IS_POST) {
            $this->checkToken();
            echo json_encode(D("News")->addNews());
        } else {
            $this->assign("list", D("News")->category());
            $this->display();
        }
    }

    public function checkNewsTitle() {
        $M = M("News");
        $where = "title='" . $this->_get('title') . "'";
        if (!empty($_GET['id'])) {
            $where.=" And id !=" . (int) $_GET['id'];
        }
        if ($M->where($where)->count() > 0) {
            echo json_encode(array("status" => 0, "info" => "已经存在，请修改标题"));
        } else {
            echo json_encode(array("status" => 1, "info" => "可以使用"));
        }
    }

    public function edit() {
        $M = M("News");
        if (IS_POST) {
            $this->checkToken();
            echo json_encode(D("News")->edit());
        } else {
            $info = $M->where("id=" . (int) $_GET['id'])->find();
            if ($info['id'] == '') {
                $this->error("不存在该记录");
            }
            $this->assign("info", $info);
            $this->assign("list", D("News")->category());
            $this->display("add");
        }
    }

    public function del() {
		$temp = M("News")->where("id=" . (int) $_GET['id'])->find();
    	
        if (M("News")->where("id=" . (int) $_GET['id'])->delete()) {
        	@unlink(C("TMPL_PARSE_STRING.__newspic__").$temp['pic']);
        	//@unlink('./Uploads/image/news/'.$temp['pic']);
            $this->success("成功删除");
            //echo json_encode(array("status"=>1,"info"=>""));
        } else {
            $this->error("删除失败，可能是不存在该ID的记录");
        }
    }
    
    public function picture(){
    	$list = M('Picture')->order('id desc')->select();
    	
    	$status = array('禁止','正常');
    	
    	foreach ($list as $k=>$v){
    		$list[$k]['statusname'] =  $status[$v['status']];
    	}
    	
    	$this->assign('list',$list);
    	$this->display();
    }
    
    public function picturedel() {
    	$temp = M("Picture")->where("id=" . (int) $_GET['id'])->find();
    	
        if (M('Picture')->where("id=" . (int) $_GET['id'])->delete()) {
        	@unlink(C("TMPL_PARSE_STRING.__pictureimg__").$temp['img']);
        	@unlink(C("TMPL_PARSE_STRING.__pictureimg__").'m_'.$temp['img']);
            $this->success("成功删除");
            //echo json_encode(array("status"=>1,"info"=>""));
        } else {
            $this->error("删除失败，可能是不存在该ID的记录");
        }
    }
    
    public function pictureedit(){
    	if (IS_POST) {
    		$this->checkToken();
    		$data = $_POST['info'];
    		
    		import('ORG.Net.UploadFile');
    		$upload = new UploadFile();// 实例化上传类
    		$upload->maxSize  = 3145728 ;// 设置附件上传大小
    		$upload->saveRule  = date('Ymj').'_p'.time();// 设置文件名
    		$upload->allowExts  = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
    		$upload->savePath =  C("TMPL_PARSE_STRING.__pictureimg__");// 设置附件上传目录
    		$upload->thumb = true; 
    		// 设置引用图片类库包路径 
    		$upload->imageClassPath = 'ORG.Util.Image'; 
    		//设置需要生成缩略图的文件后缀 
    		$upload->thumbPrefix = 'm_';  //生产1张缩略图 
    		//设置缩略图最大宽度 
    		$upload->thumbMaxWidth = '220'; 
    		//设置缩略图最大高度 
    		$upload->thumbMaxHeight = '220'; 
    		
    		if(!$upload->upload()) {
    			//$this->error($upload->getErrorMsg());// 上传错误提示错误信息
    		}else{
    			$info =  $upload->getUploadFileInfo();// 上传成功 获取上传文件信息
    		}
    		
    		if($info){
    			@unlink(C("TMPL_PARSE_STRING.__pictureimg__").$data['img']);
    			@unlink(C("TMPL_PARSE_STRING.__pictureimg__").'m_'.$data['img']);
    			$data['img'] = $info[0]['savename'];
    		}
    		
    		if (M('Picture')->save($data)) {
    			echo json_encode(array('status' => 1, 'info' => "已经更新", 'url' => U('News/picture')));
    		}else {
    			echo json_encode(array('status' => 0, 'info' => "更新失败，请刷新页面尝试操作"));
    		}
    	}else {
    		$info = M('Picture')->where("id=" . (int) $_GET['id'])->find();
            if ($info['id'] == '') {
                $this->error("不存在该记录");
            }
            $this->assign("info", $info);
    		$this->display('pictureadd');
    	}
    }
    
    public function pictureadd(){
    	if (IS_POST) {
    		$this->checkToken();
    		$data = $_POST['info'];
    		$data['published'] = time();
    		
    		import('ORG.Net.UploadFile');
    		$upload = new UploadFile();// 实例化上传类
    		$upload->maxSize  = 3145728 ;// 设置附件上传大小
    		$upload->saveRule  = date('Ymj').'_p'.time();// 设置文件名
    		$upload->allowExts  = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
    		$upload->savePath =  C("TMPL_PARSE_STRING.__pictureimg__");// 设置附件上传目录
    		$upload->thumb = true; 
    		// 设置引用图片类库包路径 
    		$upload->imageClassPath = 'ORG.Util.Image'; 
    		//设置需要生成缩略图的文件后缀 
    		$upload->thumbPrefix = 'm_';  //生产1张缩略图 
    		//设置缩略图最大宽度 
    		$upload->thumbMaxWidth = '220'; 
    		//设置缩略图最大高度 
    		$upload->thumbMaxHeight = '220'; 
    		
    		if(!$upload->upload()) {
    			//$this->error($upload->getErrorMsg());// 上传错误提示错误信息
    		}else{
    			$info =  $upload->getUploadFileInfo();// 上传成功 获取上传文件信息
    		}
    		
    		if($info){
    			@unlink(C("TMPL_PARSE_STRING.__pictureimg__").$data['img']);
    			@unlink(C("TMPL_PARSE_STRING.__pictureimg__").'m_'.$data['img']);
    			$data['img'] = $info[0]['savename'];
    		}
    		
    		if (M('Picture')->add($data)) {
    			echo json_encode(array('status' => 1, 'info' => "已经发布", 'url' => U('News/picture')));
    		}else {
    			echo json_encode(array('status' => 0, 'info' => "发布失败，请刷新页面尝试操作"));
    		}
    	}else {
    		$this->display();
    	}
    }

}