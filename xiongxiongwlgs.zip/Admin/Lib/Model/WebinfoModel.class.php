<?php

class WebinfoModel extends Model {

    public function set_site_info() {
        
    }

}

?>
