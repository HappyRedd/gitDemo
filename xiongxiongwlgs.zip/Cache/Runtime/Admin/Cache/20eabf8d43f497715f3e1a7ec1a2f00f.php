<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>首页 - 后台管理中心 - <?php echo ($site["SITE_INFO"]["name"]); ?></title>
        <?php $addCss=""; $addJs=""; $currentNav ='网站管理 > 后台首页'; ?>
        <base href="<?php echo ($site["WEB_ROOT"]); ?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo ($site["WEB_ROOT"]); ?>Public/Min/?f=../Public/Css/base.css|../Public/Css/layout.css|__PUBLIC__/Js/asyncbox/skins/default.css<?php echo ($addCss); ?>" />
<script type="text/javascript" src="<?php echo ($site["WEB_ROOT"]); ?>Public/Min/?f=__PUBLIC__/Js/jquery-1.9.0.min.js|__PUBLIC__/Js/jquery.lazyload.js|__PUBLIC__/Js/functions.js|../Public/Js/base.js|__PUBLIC__/Js/jquery.form.js|__PUBLIC__/Js/asyncbox/asyncbox.js<?php echo ($addJs); ?>"></script>
    </head>
    <body>
        <div class="wrap">
            <div id="Top">
    <div class="logo"><img src="../Public/Img/logo.gif" /></div>
    <div class="help"><a href="__APP__/Index/system">系统信息</a><span><a href="<?php echo ($site["WEB_ROOT"]); ?>" target="_blank">首页</a></span></div>
    <div class="menu">
        <ul> <?php echo ($menu); ?> </ul>
    </div>
</div>
<div id="Tags">
    <div class="userPhoto"><img src="../Public/Img/userPhoto.jpg" /> </div>
    <div class="navArea">
        <div class="userInfo"><div><a href="<?php echo U('Webinfo/index');?>" class="sysSet"><span>&nbsp;</span>系统设置</a> <a href="<?php echo U("Public/loginOut");?>" class="loginOut"><span>&nbsp;</span>退出系统</a></div>欢迎您，<?php echo ($my_info["email"]); ?> | <a href="#">个人信息管理</a> | <a href="#">个人信息管理</a> | <a href="#">个人信息管理</a></div>
        <div class="nav"><font id="today"><?php echo date("Y-m-d H:i:s"); ?></font>您的位置：<?php echo ($currentNav); ?></div>
    </div>
</div>
<div class="clear"></div>
            <div class="mainBody">
                <div id="Left">
    <div id="control" class=""></div>
    <div class="subMenuList">
        <div class="itemTitle"><?php if(MODULE_NAME == 'Index'): ?>常用操作<?php else: ?>子菜单<?php endif; ?> </div>
        <ul>
            <?php if(is_array($sub_menu)): foreach($sub_menu as $key=>$sv): ?><li><a href="<?php echo ($sv["url"]); ?>"><?php echo ($sv["title"]); ?></a></li><?php endforeach; endif; ?>
        </ul>
    </div>
</div>
                <div id="Right">
                    <div class="Item hr">
                        <div class="current">系统信息</div>
                    </div>
					
					<table width="100%" border="0" cellspacing="0" cellpadding="0" class="tab">
					<tr>
						<td width="120" align="right">网站名称：</td>
							<td><?php echo ($site["SITE_INFO"]["name"]); ?></td>
					</tr>
					
					</table>
					<div class="Item hr">
                        <div class="current">关于我们</div>
                    </div>
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" class="tab">
					<tr>
						<td width="120" align="right">系统名称：</td>
							<td>企业网站管理系统</td>
					</tr>
					<tr>
						<td width="120" align="right">系统版本：</td>
							<td><?php echo ($site["SITE_INFO"]["version"]); ?></td>
					</tr>
					<tr>
						<td width="120" align="right">程序开发：</td>
							<td>肖乐</td>
					</tr>
					<tr>
						<td width="120" align="right">界面设计：</td>
							<td>肖乐</td>
					</tr>
					<tr>
						<td width="120" align="right">版权所有：</td>
							<td>www.eyun361.com </td>
					</tr>
					<tr>
						<td width="120" align="right">许可协议：</td>
							<td>任何网站转载本站点内容时需注明来源。否则将根据《<a href="http://www.cnnic.cn/ggfw/fwzxxgzcfg/2010/201207/t20120720_32417.htm" target="_blank">互联网著作权行政保护办法</a>》追究其相应法律责任。<br/>
							 如因作品内容、版权和其它问题需要同本网联系的，请与我取得联系，联系QQ:345179552。<br/>
							 本系统为内部定制软件系统，由肖乐开发，未经授权，您不得复制、镜像、传播，修改本软件版权，否则我司将追究其相关法律责任。 </td>
					</tr>

					</table>
                </div>
            </div>
        </div>
        <div class="clear"></div>
        <div id="Bottom">Copyright &copy; 2010 - <?php echo (date("Y",NOW_TIME)); ?> Duzui.org All Rights Reserved.</div>
<script type="text/javascript">
    $(window).resize(autoSize);
    $(function(){
        autoSize();
        $(".loginOut").click(function(){
            var url=$(this).attr("href");
            popup.confirm('你确定要退出吗？','你确定要退出吗',function(action){
                if(action == 'ok'){ window.location=url; }
            });
            return false;
        });

        var time=self.setInterval(function(){$("#today").html(date("Y-m-d H:i:s"));},1000);


    });

</script>
        <script type="text/javascript">
            $(function(){
                $.post("<?php echo U('SysData/backup');?>", { systemBackup: 1 },function(json){
                    if(json.status==1){
                        popup.success(json.info,"系统定期备份成功提醒");
                    }
                });
            });
        </script>
    </body>
</html>