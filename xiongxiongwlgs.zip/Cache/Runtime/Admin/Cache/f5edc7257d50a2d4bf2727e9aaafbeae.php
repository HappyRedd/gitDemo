<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>站点配置 - 系统设置 - 后台管理中心 - <?php echo ($site["SITE_INFO"]["name"]); ?></title>
    <?php $addCss=""; ?>
    <?php $addJs=""; ?>
    <base href="<?php echo ($site["WEB_ROOT"]); ?>"/>
<link rel="stylesheet" type="text/css" href="<?php echo ($site["WEB_ROOT"]); ?>Public/Min/?f=../Public/Css/base.css|../Public/Css/layout.css|__PUBLIC__/Js/asyncbox/skins/default.css<?php echo ($addCss); ?>" />
<script type="text/javascript" src="<?php echo ($site["WEB_ROOT"]); ?>Public/Min/?f=__PUBLIC__/Js/jquery-1.9.0.min.js|__PUBLIC__/Js/jquery.lazyload.js|__PUBLIC__/Js/functions.js|../Public/Js/base.js|__PUBLIC__/Js/jquery.form.js|__PUBLIC__/Js/asyncbox/asyncbox.js<?php echo ($addJs); ?>"></script>
</head>
<body>
    <div class="wrap"> <div id="Top">
    <div class="logo"><img src="../Public/Img/logo.gif" /></div>
    <div class="help"><a href="__APP__/Index/system">系统信息</a><span><a href="<?php echo ($site["WEB_ROOT"]); ?>" target="_blank">首页</a></span></div>
    <div class="menu">
        <ul> <?php echo ($menu); ?> </ul>
    </div>
</div>
<div id="Tags">
    <div class="userPhoto"><img src="../Public/Img/userPhoto.jpg" /> </div>
    <div class="navArea">
        <div class="userInfo"><div><a href="<?php echo U('Webinfo/index');?>" class="sysSet"><span>&nbsp;</span>系统设置</a> <a href="<?php echo U("Public/loginOut");?>" class="loginOut"><span>&nbsp;</span>退出系统</a></div>欢迎您，<?php echo ($my_info["email"]); ?> | <a href="#">个人信息管理</a> | <a href="#">个人信息管理</a> | <a href="#">个人信息管理</a></div>
        <div class="nav"><font id="today"><?php echo date("Y-m-d H:i:s"); ?></font>您的位置：<?php echo ($currentNav); ?></div>
    </div>
</div>
<div class="clear"></div>
        <div class="mainBody"> <div id="Left">
    <div id="control" class=""></div>
    <div class="subMenuList">
        <div class="itemTitle"><?php if(MODULE_NAME == 'Index'): ?>常用操作<?php else: ?>子菜单<?php endif; ?> </div>
        <ul>
            <?php if(is_array($sub_menu)): foreach($sub_menu as $key=>$sv): ?><li><a href="<?php echo ($sv["url"]); ?>"><?php echo ($sv["title"]); ?></a></li><?php endforeach; endif; ?>
        </ul>
    </div>
</div>
            <div id="Right">
                <div class="contentArea">
                    <div class="Item hr">
                        <div class="current">站点配置</div>
                    </div>
                    <form action="" method="post">
                        <table width="100%" border="0" cellspacing="0" cellpadding="0" class="table1">
                            <tr>
                                <th width="120">站点名称：</th>
                                <td><input name="name" type="text" class="input" size="40" value="<?php echo ($site["SITE_INFO"]["name"]); ?>" /></td>
                            </tr>
							<tr>
                                <th width="120">站点LOGO：</th>
                                <td><input type="file" class="input" name='upload'> 请使用gif格式的图片 350*80</td>
                            </tr>
                            <tr>
                                <th width="120">网站版本：</th>
                                <td><input name="version" type="text" class="input" size="40" value="<?php echo ($site["SITE_INFO"]["version"]); ?>" /></td>
                            </tr>
                            <tr>
                                <th>ICP备案：</th>
                                <td><input class="input" name="icp" type="text" size="40" value="<?php echo ($site["SITE_INFO"]["icp"]); ?>" /></td>
                            </tr>
                            <tr>
                                <th>客服邮箱：</th>
                                <td><input class="input" name="service" type="text" size="40" value="<?php echo ($site["SITE_INFO"]["service"]); ?>" /></td>
                            </tr>
                            <tr>
                                <th>客服电话：</th>
                                <td><input class="input" name="tel" type="text" size="40" value="<?php echo ($site["SITE_INFO"]["tel"]); ?>" /></td>
                            </tr>
							<tr>
                                <th>客服QQ：</th>
                                <td><input class="input" name="qq" type="text" size="40" value="<?php echo ($site["SITE_INFO"]["qq"]); ?>" /></td>
                            </tr>
                            <tr>
                                <th>传真号码：</th>
                                <td><input class="input" name="fax" type="text" size="40" value="<?php echo ($site["SITE_INFO"]["fax"]); ?>" /></td>
                            </tr>
                            <tr>
                                <th>公司地址：</th>
                                <td><input class="input" name="address" type="text" size="40" value="<?php echo ($site["SITE_INFO"]["address"]); ?>" /></td>
                            </tr>
                            <tr>
                                <th>邮政编码：</th>
                                <td><input class="input" name="postcode" type="text" size="40" value="<?php echo ($site["SITE_INFO"]["postcode"]); ?>" /></td>
                            </tr>
                            <tr>
                                <th>网站关键字：</th>
                                <td><input class="input" name="keyword" type="text" size="40" value="<?php echo ($site["SITE_INFO"]["keyword"]); ?>" /></td>
                            </tr>
                            <tr>
                                <th>网站简介：</th>
                                <td><textarea name="description" cols="100" rows="2"><?php echo ($site["SITE_INFO"]["description"]); ?></textarea></td>
                            </tr>
							<tr>
                                <th>底部版权：</th>
                                <td><textarea name="copyright" cols="100" rows="2"><?php echo ($site["SITE_INFO"]["copyright"]); ?></textarea></td>
                            </tr>
							<tr>
                                <th>统计代码：</th>
                                <td><textarea name="tongji" cols="100" rows="2"><?php echo ($site["SITE_INFO"]["tongji"]); ?></textarea></td>
                            </tr>
                        </table>
                    </form>
                    <div class="commonBtnArea" >
                        <button class="btn submit">提交</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="clear"></div>
<div id="Bottom">Copyright &copy; 2010 - <?php echo (date("Y",NOW_TIME)); ?> Duzui.org All Rights Reserved.</div>
<script type="text/javascript">
    $(window).resize(autoSize);
    $(function(){
        autoSize();
        $(".loginOut").click(function(){
            var url=$(this).attr("href");
            popup.confirm('你确定要退出吗？','你确定要退出吗',function(action){
                if(action == 'ok'){ window.location=url; }
            });
            return false;
        });

        var time=self.setInterval(function(){$("#today").html(date("Y-m-d H:i:s"));},1000);


    });

</script>
<script type="text/javascript">
    $(".submit").click(function(){
        commonAjaxSubmit();
    });
</script>
</body>
</html>