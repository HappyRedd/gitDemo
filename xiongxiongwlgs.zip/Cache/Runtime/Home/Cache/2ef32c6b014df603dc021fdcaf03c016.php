<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>网站建设 - <?php echo ($systemConfig["SITE_INFO"]["name"]); ?></title>
<meta name="keywords" content="<?php echo ($systemConfig["SITE_INFO"]["keyword"]); ?>" />
<meta name="description" content="<?php echo ($systemConfig["SITE_INFO"]["description"]); ?>" />
﻿<link rel="stylesheet" type="text/css" href="__PUBLIC__/Css/Default/style.css" />
﻿<script type="text/javascript" src="__PUBLIC__/Js/jquery-1.7.2.min.js"></script>
﻿<script type="text/javascript" src="__PUBLIC__/Js/Default/common.js"></script>

<link id="favicon" href="/favicon.ico" rel="icon" type="image/x-icon" />
<link rel="alternate" type="application/rss+xml" title="<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>官方资讯" href="__APP__/rss.html" />
</head>

<body>
﻿<div id="header">
	<img src="__PUBLIC__/Images/logo.gif" class="logo" />
    <div id="nav" class="nav">
    	<ul>
        	<li id="nav_index"><a href="__APP__/index.html">网站首页</a></li>
            <li id="nav_website"><a href="<?php echo U('/website');?>">网站建设</a></li>
			<li id="nav_host"><a href="<?php echo U('/host');?>">主机租凭</a></li>
			<li id="nav_picture"><a href="<?php echo U('/picture');?>">案例展示</a></li>
			<li id="nav_news"><a href="<?php echo U('/news');?>">新闻动态</a>
				<ul>
					<?php if(is_array($categorylist)): $i = 0; $__LIST__ = $categorylist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li id="nav_news"><a href="<?php echo U('/news/category/'.$vo['cid'].'');?>"><?php echo ($vo["name"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
			</li>
			<li id="nav_about"><a href="<?php echo U('/about');?>">关于我们</a></li>
			<li id="nav_contact"><a href="<?php echo U('/contact');?>">联系我们</a></li>
        </ul>
    </div>
    <script type="text/javascript">mynav.init({navid: "nav"});var nav = document.getElementById('nav_<?php echo (ACTION_NAME); ?>');nav.className=nav.className+" on";</script>
</div>
<style type="text/css">
a.btn_build {width:202px; height:53px; display:block; position:absolute; left:50%; top:300px; z-index:99; margin-left:130px; background:url(__PUBLIC__/Images/Default/btn_build.png);}
a.btn_build:hover {background:url(__PUBLIC__/Images/Default/btn_build.png) -202px;}
</style>
<div id="banner" style="background:#73AAE7; border-top:1px solid #5E98D7; position:relative;">
	<center><img src="__PUBLIC__/Images/Default/poster_build_pic.jpg" /></center>
    <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($systemConfig["SITE_INFO"]["qq"]); ?>&site=<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>&menu=yes" target="_blank" title="立即建站" class="btn_build">&nbsp;</a>
</div>
<div id="box">
	<div style="height:1200px;">
		<img src="__PUBLIC__/Images/Default/content/website_1.jpg" alt="网站不是白菜，便宜没有好货">
	</div>
	<img src="__PUBLIC__/Images/Default/content/website_2.jpg" width="1000" alt="网站建设流程" />
	<div style="position:absolute;z-index:2;top:250px;left:50px;width:710px;font-size:14px;line-height:30px;">
		<p>不管是刚刚起步的公司，对网站功能要求不多，只是想要拥有公司网站，让更多人了解公司；</p>
		<p>还是传统行业、工厂型企业，虽不太可能在网上形成订单，但网站却可以展示企业形象，能让更多客户了解并联系企业，从而间接的形成线下的订单；</p>
		<p>或是科技公司，想要通过网站更直接地让客户了解公司的产品和服务。</p>
		<p>无论您属于以上哪种类型，企业展示型网站都是一个很好的平台，通过这个平台，将企业理念和文化传达给客户。用最亮眼的展现方式来告诉客户自己产品最核心的特色及价值。</p>
	</div>
	<div style="position:absolute;z-index:2;top:550px;left:335px;width:635px;font-size:14px;line-height:30px;">
		<p><b>做一个网站多少钱？</b></p>
		<p style="text-indent:28px;">企业展示型网站600元起(一年)，包括域名和空间，自有域名空间的500元，续费：300元。网站页面包括：首页、公司简介、图片展示、产品中心、新闻中心、在线留言、在线客服等。网站完成后我们会给客户一个管理后台，网站内容由客户自行在后台添加或修改，如客户自己没时间的，<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>提供网站托管服务，包括网站维护、内容更新等，需另外收取500元费用。网站logo设计单独收取100元，快速备案200元(默认使用香港空间，无需备案)，简繁双语的网站另加300元，英汉双语的网站另加500元。</p><br />
		<p><b>个人可以做网站吗？</b></p>
		<p style="text-indent:28px;">可以的，个人网站的费用是300元(一年)，续费也是300元。</p><br />
		<p><b>我想做个论坛或者商城网站，费用是不是比企业展示型的高很多？</b></p>
		<p style="text-indent:28px;">论坛和商城类的网站通常使用Discuz和Ecshop这两个开源的程序制作，收费300元，包括域名和一个基础型的虚拟主机，只适合前期运营，当论坛或商城运作一段时间流量大了以后，可自行更换服务器或补上差价由我们代为更换。</p><br />
		<p><b>听说网站备案很麻烦，都需要提供什么材料？</b></p>
		<p style="text-indent:28px;"><?php echo ($systemConfig["SITE_INFO"]["name"]); ?>提供快速备案服务，比您自己备案的速度快3倍，需要客户提供的材料有：营业执照原件彩色扫描件、法人身份证原件正反面彩色扫描件、网站负责人身份证原件正反面彩色扫描件、网站负责人照片（到指定地点），如果法人做网站负责人的话，提供一张身份证扫描件就行，照片也要是法人的</p><br />
	</div>
</div>
﻿<div id="bottom">
	<div class="bbox">
        <div class="moduletable">
            <h4>关于</h4>
            <ul>
                <li><a href="<?php echo U('/about');?>">关于我们</a></li>
				<li><a href="<?php echo U('/contact');?>">联系我们</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>业务</h4>
            <ul>
				<li><a href="<?php echo U('/website');?>">网站建设</a></li>
                <li><a href="<?php echo U('/host');?>">主机租赁</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>联系</h4>
            <ul>
				<li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($systemConfig["SITE_INFO"]["qq"]); ?>&site=<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>&menu=yes" target="_blank">在线咨询</a></li>
                <li><a href="mailto:<?php echo ($systemConfig["SITE_INFO"]["service"]); ?>">邮件咨询</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>支持</h4>
            <ul>
                <li><a href="<?php echo U('/picture');?>">网站案例</a></li>
				<li><a href="<?php echo U('/news');?>">新闻动态</a></li>
				<li><a href="<?php echo U('/rss');?>" target="_blank" title="Rss订阅">文章订阅</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>案例</h4>
            <ul>
				<?php if(is_array($picturelist)): $i = 0; $__LIST__ = $picturelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li><a href="<?php echo ($vo["url"]); ?>" rel="external nofollow" target="_blank"><?php echo ($vo["title"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>扫一扫</h4>
            <img src="__PUBLIC__/Images/Default/erweima.gif" />
        </div>
  </div>
</div>
<div id="footer"><?php echo ($systemConfig["SITE_INFO"]["copyright"]); echo ($systemConfig["SITE_INFO"]["icp"]); ?></div>
<div style="display:none">
<?php echo ($systemConfig["SITE_INFO"]["tongji"]); ?>
</div>
<a href="javascript:;" class="top"></a>
</body>
</html>