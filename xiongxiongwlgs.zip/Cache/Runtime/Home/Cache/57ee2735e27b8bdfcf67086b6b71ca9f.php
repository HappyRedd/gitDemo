<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>关于我们 - <?php echo ($systemConfig["SITE_INFO"]["name"]); ?></title>
<meta name="keywords" content="<?php echo ($systemConfig["SITE_INFO"]["keyword"]); ?>" />
<meta name="description" content="<?php echo ($systemConfig["SITE_INFO"]["description"]); ?>" />
﻿<link rel="stylesheet" type="text/css" href="__PUBLIC__/Css/Default/style.css" />
﻿<script type="text/javascript" src="__PUBLIC__/Js/jquery-1.7.2.min.js"></script>
﻿<script type="text/javascript" src="__PUBLIC__/Js/Default/common.js"></script>

<link id="favicon" href="/favicon.ico" rel="icon" type="image/x-icon" />
<link rel="alternate" type="application/rss+xml" title="<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>官方资讯" href="__APP__/rss.html" />
</head>

<body>
﻿<div id="header">
	<img src="__PUBLIC__/Images/logo.gif" class="logo" />
    <div id="nav" class="nav">
    	<ul>
        	<li id="nav_index"><a href="__APP__/index.html">网站首页</a></li>
            <li id="nav_website"><a href="<?php echo U('/website');?>">网站建设</a></li>
			<li id="nav_host"><a href="<?php echo U('/host');?>">主机租凭</a></li>
			<li id="nav_picture"><a href="<?php echo U('/picture');?>">案例展示</a></li>
			<li id="nav_news"><a href="<?php echo U('/news');?>">新闻动态</a>
				<ul>
					<?php if(is_array($categorylist)): $i = 0; $__LIST__ = $categorylist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li id="nav_news"><a href="<?php echo U('/news/category/'.$vo['cid'].'');?>"><?php echo ($vo["name"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
			</li>
			<li id="nav_about"><a href="<?php echo U('/about');?>">关于我们</a></li>
			<li id="nav_contact"><a href="<?php echo U('/contact');?>">联系我们</a></li>
        </ul>
    </div>
    <script type="text/javascript">mynav.init({navid: "nav"});var nav = document.getElementById('nav_<?php echo (ACTION_NAME); ?>');nav.className=nav.className+" on";</script>
</div>
<div id="banner" style="background:#0d345b; position:relative; margin-bottom:30px;">
	<center><img src="__PUBLIC__/Images/Default/content/banner_about.jpg" /></center>
</div>
<div id="box">
	<div style="width:350px; height:200px; float:left;"><img src="__PUBLIC__/Images/Default/lou.jpg" /></div>
    <div style="width:650px; height:auto; line-height:24px; text-indent:28px; float:left; font-size:14px;">
    	<p><?php echo ($systemConfig["SITE_INFO"]["name"]); ?>经过多年的发展，<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>已成为一家专业的互联网应用技术及网络传播服务提供商，致力为用户提供成熟的互联网应用技术与专业的网络传播服务。</p><br />
        <p><?php echo ($systemConfig["SITE_INFO"]["name"]); ?>凭借着对互联网行业的独到见解和丰富经验，在项目策划、项目管理、设计制作、技术开发和网络传播等多方面寻求平衡；在项目过程中，<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>通过周密的策划、深入的调查、理性的分析、精妙的创意、专业的实施，并同客户的实际情况和具体需求进行良好结合，为不同类型的客户提供最佳的互联网应用定制解决方案，帮助客户在新的全球化互联网环境中保持优势。</p><br />
        <p><?php echo ($systemConfig["SITE_INFO"]["name"]); ?>秉承先进的互联网应用技术和领先的网络传播理念，建立了科学的管理机制和强有力的服务体系；专业资深的互联网应用技术服务团队将以最优化的资源配置与最佳的网络传播方式为源动力，为<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>庞大而优秀的客户群体打造网络新形象，正是<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>的独到之处。</p><br /><br />
    </div>
    <div style="width:650px; height:auto; line-height:24px; float:left; padding-right:50px; font-size:14px;">
    	<p style="font-size:18px;"><strong>公司理念</strong></p> 
		<p>分享： 一个人最大的智慧就是与别人分享，只有分享的思想才有力量； </p> 
		<p>创新： 创新是旧的资源新的整合，创新是<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>事业发展的灵魂， 与时俱进是创新的最佳体现；</p> 
		<p>沟通： 每一位<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>人都要致力于在团队中减少相互之间的误解和被误解； </p> 
		<p>超越： 勇于跟自己较劲儿，把每一件小事情都要做完整、做到位；</p> 
		<p>积极： 体现自我价值、追求团队价值； </p> <br />
		<p style="text-indent:28px;">以人为核心、以诚信服务客户、以科技创新为手段、 以为客户创造价值为己任，通过内部集体学习提高企业价值，以坚持不懈的精神实现企业战略目标。</p> 
    </div>
	<div style="width:300px; height:300px; float:left;"><img src="__PUBLIC__/Images/Default/jianpan.jpg" /></div>
</div>
﻿<div id="bottom">
	<div class="bbox">
        <div class="moduletable">
            <h4>关于</h4>
            <ul>
                <li><a href="<?php echo U('/about');?>">关于我们</a></li>
				<li><a href="<?php echo U('/contact');?>">联系我们</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>业务</h4>
            <ul>
				<li><a href="<?php echo U('/website');?>">网站建设</a></li>
                <li><a href="<?php echo U('/host');?>">主机租赁</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>联系</h4>
            <ul>
				<li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($systemConfig["SITE_INFO"]["qq"]); ?>&site=<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>&menu=yes" target="_blank">在线咨询</a></li>
                <li><a href="mailto:<?php echo ($systemConfig["SITE_INFO"]["service"]); ?>">邮件咨询</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>支持</h4>
            <ul>
                <li><a href="<?php echo U('/picture');?>">网站案例</a></li>
				<li><a href="<?php echo U('/news');?>">新闻动态</a></li>
				<li><a href="<?php echo U('/rss');?>" target="_blank" title="Rss订阅">文章订阅</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>案例</h4>
            <ul>
				<?php if(is_array($picturelist)): $i = 0; $__LIST__ = $picturelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li><a href="<?php echo ($vo["url"]); ?>" rel="external nofollow" target="_blank"><?php echo ($vo["title"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>扫一扫</h4>
            <img src="__PUBLIC__/Images/Default/erweima.gif" />
        </div>
  </div>
</div>
<div id="footer"><?php echo ($systemConfig["SITE_INFO"]["copyright"]); echo ($systemConfig["SITE_INFO"]["icp"]); ?></div>
<div style="display:none">
<?php echo ($systemConfig["SITE_INFO"]["tongji"]); ?>
</div>
<a href="javascript:;" class="top"></a>
</body>
</html>