<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>案例展示 - <?php echo ($systemConfig["SITE_INFO"]["name"]); ?></title>
<meta name="keywords" content="<?php echo ($systemConfig["SITE_INFO"]["keyword"]); ?>" />
<meta name="description" content="<?php echo ($systemConfig["SITE_INFO"]["description"]); ?>" />
﻿<link rel="stylesheet" type="text/css" href="__PUBLIC__/Css/Default/style.css" />
﻿<script type="text/javascript" src="__PUBLIC__/Js/jquery-1.7.2.min.js"></script>
﻿<script type="text/javascript" src="__PUBLIC__/Js/Default/common.js"></script>

<link id="favicon" href="/favicon.ico" rel="icon" type="image/x-icon" />
<link rel="alternate" type="application/rss+xml" title="<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>官方资讯" href="__APP__/rss.html" />
</head>

<body>
﻿<div id="header">
	<img src="__PUBLIC__/Images/logo.gif" class="logo" />
    <div id="nav" class="nav">
    	<ul>
        	<li id="nav_index"><a href="__APP__/index.html">网站首页</a></li>
            <li id="nav_website"><a href="<?php echo U('/website');?>">网站建设</a></li>
			<li id="nav_host"><a href="<?php echo U('/host');?>">主机租凭</a></li>
			<li id="nav_picture"><a href="<?php echo U('/picture');?>">案例展示</a></li>
			<li id="nav_news"><a href="<?php echo U('/news');?>">新闻动态</a>
				<ul>
					<?php if(is_array($categorylist)): $i = 0; $__LIST__ = $categorylist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li id="nav_news"><a href="<?php echo U('/news/category/'.$vo['cid'].'');?>"><?php echo ($vo["name"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
			</li>
			<li id="nav_about"><a href="<?php echo U('/about');?>">关于我们</a></li>
			<li id="nav_contact"><a href="<?php echo U('/contact');?>">联系我们</a></li>
        </ul>
    </div>
    <script type="text/javascript">mynav.init({navid: "nav"});var nav = document.getElementById('nav_<?php echo (ACTION_NAME); ?>');nav.className=nav.className+" on";</script>
</div>
<div id="banner" style="background:#0d345b; position:relative; margin-bottom:30px;">
	<center><img src="__PUBLIC__/Images/Default/content/banner_picture.jpg" /></center>
</div>
<h1 class="pictureh1">网站案例</h1>
<div id="box">
    <dl id="picbox">
        <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><dd class="imgbox">
        	<img src="__pictureimg__m_<?php echo ($vo["img"]); ?>" />
            <div class="shade" data="<?php echo (($vo["url"])?($vo["url"]):"__APP__/index.html"); ?>">
            	<?php echo ($vo["title"]); ?>
                <span class="imgpath">
                	<img src="__pictureimg__<?php echo ($vo["img"]); ?>" />
                </span>
            </div>
        </dd><?php endforeach; endif; else: echo "" ;endif; ?>
    </dl>
</div>

<script type="text/javascript">
$(function(){var e=0,t=$(document).width(),n={marginLeft:$("#box").css("margin-left")},r={leftWidth:0,imgIndex:0},i={height:$("#picbox").height()};$("#box").wrap('<div id="body"></div>'),$("#body").append('<div id="picboxbottom"></div><div id="picbottom" style="text-align:center;margin-top:10px;display:none;"><a href="#" id="pre" title="返 回" style="height:36px;line-height:36px;font-size:24px;">返 回</a></div>').css({position:"relative","overflow-x":"hidden",width:t+"px"}),$("#picboxbottom").css({left:t+"px"}),$(".imgbox").hover(function(){$(this).find(".shade").stop(!0,!0).fadeTo(200,.9)},function(){$(this).find(".shade").stop(!0,!0).fadeOut(200)}),$(".shade").click(function(){$("#picbottom").fadeIn();var n=$(this).attr("data");$("#picboxbottom").html($(this).find(".imgpath").html()).find("img").wrap('<a href="'+n+'" target="_blank"></a>'),imgReady($(this).find(".imgpath img:first").attr("src"),function(){$("#picbox").height(this.height),r.leftWidth=(t-this.width)/2+this.width,$("#picboxbottom").find("img:eq("+r.imgIndex+")").css({"margin-right":(t-this.width)/2+"px"}),r.imgIndex++,e=$(document).scrollTop(),$("body, html").animate({scrollTop:"110px"}),$("#box").animate({"margin-left":"-1000px"}),$("#picboxbottom").animate({left:(t-this.width)/2+"px"})})}),$("#pre").click(function(){return r.imgIndex==1?($("#box").animate({"margin-left":n.marginLeft}),$("#picboxbottom").animate({left:t+"px"},function(){$(this).html(""),$("#picbox").animate({height:i.height})}),$("body, html").animate({scrollTop:e+"px"}),r.imgIndex=0,$("#picbottom").fadeOut()):(r.imgIndex--,imgReady($("#picboxbottom").find("img:eq("+r.imgIndex+")").attr("src"),function(){r.leftWidth=r.leftWidth-this.width-(t-this.width)/2,$("#picboxbottom").stop(!0,!0).animate({left:t-r.leftWidth+"px"})})),!1}),$("#next").click(function(){return r.imgIndex==$("#picboxbottom").find("img").length?alert("木有了哦！最后一张了~"):(imgReady($("#picboxbottom").find("img:eq("+r.imgIndex+")").attr("src"),function(){r.leftWidth=r.leftWidth+this.width+(t-this.width)/2,$("#picboxbottom").find("img:eq("+r.imgIndex+")").css({"margin-right":(t-this.width)/2+"px"}),$("#picboxbottom").stop(!0,!0).animate({left:t-r.leftWidth+"px"})}),r.imgIndex++),!1}),$(window).resize(function(){window.location.reload()})})
</script>
﻿<div id="bottom">
	<div class="bbox">
        <div class="moduletable">
            <h4>关于</h4>
            <ul>
                <li><a href="<?php echo U('/about');?>">关于我们</a></li>
				<li><a href="<?php echo U('/contact');?>">联系我们</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>业务</h4>
            <ul>
				<li><a href="<?php echo U('/website');?>">网站建设</a></li>
                <li><a href="<?php echo U('/host');?>">主机租赁</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>联系</h4>
            <ul>
				<li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($systemConfig["SITE_INFO"]["qq"]); ?>&site=<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>&menu=yes" target="_blank">在线咨询</a></li>
                <li><a href="mailto:<?php echo ($systemConfig["SITE_INFO"]["service"]); ?>">邮件咨询</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>支持</h4>
            <ul>
                <li><a href="<?php echo U('/picture');?>">网站案例</a></li>
				<li><a href="<?php echo U('/news');?>">新闻动态</a></li>
				<li><a href="<?php echo U('/rss');?>" target="_blank" title="Rss订阅">文章订阅</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>案例</h4>
            <ul>
				<?php if(is_array($picturelist)): $i = 0; $__LIST__ = $picturelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li><a href="<?php echo ($vo["url"]); ?>" rel="external nofollow" target="_blank"><?php echo ($vo["title"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>扫一扫</h4>
            <img src="__PUBLIC__/Images/Default/erweima.gif" />
        </div>
  </div>
</div>
<div id="footer"><?php echo ($systemConfig["SITE_INFO"]["copyright"]); echo ($systemConfig["SITE_INFO"]["icp"]); ?></div>
<div style="display:none">
<?php echo ($systemConfig["SITE_INFO"]["tongji"]); ?>
</div>
<a href="javascript:;" class="top"></a>
</body>
</html>