<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>主机租凭 - <?php echo ($systemConfig["SITE_INFO"]["name"]); ?></title>
<meta name="keywords" content="<?php echo ($systemConfig["SITE_INFO"]["keyword"]); ?>" />
<meta name="description" content="<?php echo ($systemConfig["SITE_INFO"]["description"]); ?>" />
﻿<link rel="stylesheet" type="text/css" href="__PUBLIC__/Css/Default/style.css" />
﻿<script type="text/javascript" src="__PUBLIC__/Js/jquery-1.7.2.min.js"></script>
﻿<script type="text/javascript" src="__PUBLIC__/Js/Default/common.js"></script>

<link id="favicon" href="/favicon.ico" rel="icon" type="image/x-icon" />
<link rel="alternate" type="application/rss+xml" title="<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>官方资讯" href="__APP__/rss.html" />
</head>

<body>
﻿<div id="header">
	<img src="__PUBLIC__/Images/logo.gif" class="logo" />
    <div id="nav" class="nav">
    	<ul>
        	<li id="nav_index"><a href="__APP__/index.html">网站首页</a></li>
            <li id="nav_website"><a href="<?php echo U('/website');?>">网站建设</a></li>
			<li id="nav_host"><a href="<?php echo U('/host');?>">主机租凭</a></li>
			<li id="nav_picture"><a href="<?php echo U('/picture');?>">案例展示</a></li>
			<li id="nav_news"><a href="<?php echo U('/news');?>">新闻动态</a>
				<ul>
					<?php if(is_array($categorylist)): $i = 0; $__LIST__ = $categorylist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li id="nav_news"><a href="<?php echo U('/news/category/'.$vo['cid'].'');?>"><?php echo ($vo["name"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
			</li>
			<li id="nav_about"><a href="<?php echo U('/about');?>">关于我们</a></li>
			<li id="nav_contact"><a href="<?php echo U('/contact');?>">联系我们</a></li>
        </ul>
    </div>
    <script type="text/javascript">mynav.init({navid: "nav"});var nav = document.getElementById('nav_<?php echo (ACTION_NAME); ?>');nav.className=nav.className+" on";</script>
</div>
<style type="text/css">
a.btn_build {width:202px; height:53px; display:block; position:absolute; left:50%; top:400px; z-index:99; margin-left:-300px; background:url(__PUBLIC__/Images/Default/btn_host.png);}
a.btn_build:hover {background:url(__PUBLIC__/Images/Default/btn_host.png) -202px;}
a.btn-danger {width:86px; height:30px; line-height:30px; display:inline-block; background:url(__PUBLIC__/Images/Default/btn-danger.gif); color:#FFF;}
a.btn-danger:hover {background:url(__PUBLIC__/Images/Default/btn-danger.gif) -86px; color:#FFF;}
</style>
<div id="banner" style="background:#F6BC20; border-top:1px solid #F6BA18;">
	<center><img src="__PUBLIC__/Images/Default/poster_host_map.jpg" /></center>
    <a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($systemConfig["SITE_INFO"]["qq"]); ?>&site=<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>&menu=yes" target="_blank" title="立即建站" class="btn_build">&nbsp;</a>
</div>
<div id="box">
	<img src="__PUBLIC__/Images/Default/title_host_1.png" style="margin:50px auto 0 auto;" />
    <table width="980" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC" style="font-size:14px;text-align:center;">
        <tr>
          <td rowspan="2" bgcolor="#FFFFFF"><span style="font-size:36px;color:#ef9a36;">热销推荐</span></td>
          <td height="80" bgcolor="#ef9a36"><span style="color:#FFF;font-size:28px;">香港Ⅰ型</span></td>
          <td height="80" bgcolor="#f6ba18"><span style="color:#FFF;font-size:28px;">香港Ⅱ型</span></td>
          <td height="80" bgcolor="#94ac26"><span style="color:#FFF;font-size:28px;">香港Ⅲ型</span></td>
          <td height="80" bgcolor="#579e34"><span style="color:#FFF;font-size:28px;">香港Ⅳ型</span></td>
        </tr>
        <tr>
          <td height="160" bgcolor="#FFFFFF"><span style="font-size:30px;color:#ef9a36;">100元/年</span></td>
          <td height="160" bgcolor="#FFFFFF"><span style="font-size:30px;color:#f6ba18;">180元/年</span></td>
          <td height="160" bgcolor="#FFFFFF"><span style="font-size:30px;color:#94ac26;">240元/年</span></td>
          <td height="160" bgcolor="#FFFFFF"><span style="font-size:30px;color:#579e34;">400元/年</span></td>
        </tr>
        <tr>
          <td height="40" bgcolor="#f9f9f9">网站空间</td>
          <td height="40" bgcolor="#f9f9f9">1G</td>
          <td height="40" bgcolor="#f9f9f9">2G</td>
          <td height="40" bgcolor="#f9f9f9">3G</td>
          <td height="40" bgcolor="#f9f9f9">4G</td>
        </tr>
        <tr>
          <td height="40" bgcolor="#f0f0f0">网站流量（每月）</td>
          <td height="40" bgcolor="#f0f0f0">30GB</td>
          <td height="40" bgcolor="#f0f0f0">60GB</td>
          <td height="40" bgcolor="#f0f0f0">90GB</td>
          <td height="40" bgcolor="#f0f0f0">150GB</td>
        </tr>
        <tr>
          <td height="40" bgcolor="#f9f9f9">操作系统</td>
          <td height="40" bgcolor="#f9f9f9">Linux</td>
          <td height="40" bgcolor="#f9f9f9">Linux</td>
          <td height="40" bgcolor="#f9f9f9">Linux</td>
          <td height="40" bgcolor="#f9f9f9">Linux</td>
        </tr>
        <tr>
          <td height="40" bgcolor="#f0f0f0">MySQL数据库</td>
          <td height="40" bgcolor="#f0f0f0">与网站空间共用</td>
          <td height="40" bgcolor="#f0f0f0">与网站空间共用</td>
          <td height="40" bgcolor="#f0f0f0">与网站空间共用</td>
          <td height="40" bgcolor="#f0f0f0">与网站空间共用</td>
        </tr>
        <tr>
          <td height="40" bgcolor="#f9f9f9">后台语言</td>
          <td height="40" bgcolor="#f9f9f9">PHP</td>
          <td height="40" bgcolor="#f9f9f9">PHP</td>
          <td height="40" bgcolor="#f9f9f9">PHP</td>
          <td height="40" bgcolor="#f9f9f9">PHP</td>
        </tr>
        <tr>
          <td height="40" bgcolor="#f0f0f0">运行版本</td>
          <td height="40" colspan="4" bgcolor="#f0f0f0">Linux + Apache2 + MySQL(5.1以上版本,支持innodb格式) + PHP(5.3以上版本)</td>
        </tr>
        <tr>
          <td height="50" bgcolor="#f9f9f9"></td>
          <td height="50" bgcolor="#f9f9f9"><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($systemConfig["SITE_INFO"]["qq"]); ?>&site=<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>&menu=yes" target="_parent" class="btn-danger">立即购买</a></td>
          <td height="50" bgcolor="#f9f9f9"><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($systemConfig["SITE_INFO"]["qq"]); ?>&site=<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>&menu=yes" target="_parent" class="btn-danger">立即购买</a></td>
          <td height="50" bgcolor="#f9f9f9"><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($systemConfig["SITE_INFO"]["qq"]); ?>&site=<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>&menu=yes" target="_blank" class="btn-danger">立即购买</a></td>
          <td height="50" bgcolor="#f9f9f9"><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($systemConfig["SITE_INFO"]["qq"]); ?>&site=<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>&menu=yes" target="_blank" class="btn-danger">立即购买</a></td>
        </tr>
    </table>
    <center><img src="__PUBLIC__/Images/Default/host_bottom.gif" /></center>
</div>
﻿<div id="bottom">
	<div class="bbox">
        <div class="moduletable">
            <h4>关于</h4>
            <ul>
                <li><a href="<?php echo U('/about');?>">关于我们</a></li>
				<li><a href="<?php echo U('/contact');?>">联系我们</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>业务</h4>
            <ul>
				<li><a href="<?php echo U('/website');?>">网站建设</a></li>
                <li><a href="<?php echo U('/host');?>">主机租赁</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>联系</h4>
            <ul>
				<li><a href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo ($systemConfig["SITE_INFO"]["qq"]); ?>&site=<?php echo ($systemConfig["SITE_INFO"]["name"]); ?>&menu=yes" target="_blank">在线咨询</a></li>
                <li><a href="mailto:<?php echo ($systemConfig["SITE_INFO"]["service"]); ?>">邮件咨询</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>支持</h4>
            <ul>
                <li><a href="<?php echo U('/picture');?>">网站案例</a></li>
				<li><a href="<?php echo U('/news');?>">新闻动态</a></li>
				<li><a href="<?php echo U('/rss');?>" target="_blank" title="Rss订阅">文章订阅</a></li>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>案例</h4>
            <ul>
				<?php if(is_array($picturelist)): $i = 0; $__LIST__ = $picturelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li><a href="<?php echo ($vo["url"]); ?>" rel="external nofollow" target="_blank"><?php echo ($vo["title"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
        
        <div class="moduletable">
            <h4>扫一扫</h4>
            <img src="__PUBLIC__/Images/Default/erweima.gif" />
        </div>
  </div>
</div>
<div id="footer"><?php echo ($systemConfig["SITE_INFO"]["copyright"]); echo ($systemConfig["SITE_INFO"]["icp"]); ?></div>
<div style="display:none">
<?php echo ($systemConfig["SITE_INFO"]["tongji"]); ?>
</div>
<a href="javascript:;" class="top"></a>
</body>
</html>