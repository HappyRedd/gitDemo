<?php

$config_arr1 = include_once WEB_ROOT . 'Common/config.php';
$config_arr2 = array(
    'URL_MODEL'            =>1,    //2是去除index.php
    //'SHOW_PAGE_TRACE'      =>True, //开启页面Trace信息显示
    'DB_FIELDTYPE_CHECK'   =>true,
    'TMPL_STRIP_SPACE'     =>true,
    'OUTPUT_ENCODE'        =>true, // 页面压缩输出
    'URL_CASE_INSENSITIVE' =>true, //URL大小写
    'DEFAULT_THEME'        =>'default',  //默认模板
    'URL_HTML_SUFFIX'      =>'.html',  //URL伪静态后缀设
    //'URL_PATHINFO_DEPR'=>'_',
    'URL_ROUTER_ON'   => true, //开启路由
    'URL_ROUTE_RULES' => array( //定义路由规则
    	'news/:id\d'               => 'News/info',
		'website'                  => 'News/website',
		'host'              	   => 'News/host',
		'picture'                  => 'News/picture',
		'news'                     => 'News/news',
		'about'                    => 'News/about',
		'contact'                  => 'News/contact',
		'rss'                      => 'News/rss',
		'category/:id\d'           => 'News/news',
	),
	
	'TMPL_PARSE_STRING'  => array(
		'__newspic__'	=>__ROOT__.'/Public/Uploads/image/news/',  //文章封面图片
		'__pictureimg__'=>__ROOT__.'/Public/Uploads/image/picture/',  //案例图片
	)
);
return array_merge($config_arr1, $config_arr2);
?>