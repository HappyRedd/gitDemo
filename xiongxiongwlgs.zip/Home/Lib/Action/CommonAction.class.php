<?php
class CommonAction extends Action {
	public function _initialize() {
        header("Content-Type:text/html; charset=utf-8");
        
        $systemConfig = include WEB_ROOT . 'Common/systemConfig.php';
		$this->assign('systemConfig', $systemConfig);
        
        $categorylist = M('Category')->where('pid=0')->select();
    	$this->assign('categorylist',$categorylist);
    	
    	$hotcatlist = M('Category')->select();
    	$this->assign('hotcatlist',$hotcatlist);
    	
		$newlist = M('News')->where('status=1')->order('id desc')->limit(6)->select();  //最新博文
		$this->assign('newlist', $newlist);
		
		$hotlist = M('News')->where('status=1')->order('views desc')->limit(6)->select();  //最热博文
		$this->assign('hotlist', $hotlist);
		
		$categorywebsite = M('Category')->getField('name,cid');
		$catlist = M('News')->where('cid='.$categorywebsite['建站知识'].' and status=1')->order('id desc')->limit(6)->select();  //建站知识
		$this->assign('catlist', $catlist);
		
		$picturelist = M('Picture')->where('status=1')->order('id desc')->limit(5)->select();
		$this->assign('picturelist', $picturelist);
	}
	
}