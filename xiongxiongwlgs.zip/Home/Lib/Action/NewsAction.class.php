<?php
class NewsAction extends CommonAction{
	
	public function website(){
		$this->display();
	}
	
	public function host(){
		$this->display();
	}
	
	public function picture(){
		
		$list = M('Picture')->where('status=1')->order('id desc')->select();
		
		$this->assign('list', $list);
		
		$this->display();
	}
	
	public function news(){
		if ($this->_get('category')){
        	$wheres['cid'] = $this->_get('category');
        }
        $wheres['status'] = 1;
		
		$Form   =   M('News');
		$count = $Form->where($wheres)->count();
        import("@.ORG.Page");
        $page = new Page($count, 5);
        $showPage = $page->show();
        $this->assign("page", $showPage);
        
        $list = $Form->where($wheres)->limit($page->firstRow, $page->listRows)->order('id desc')->select();
        
        $categorylist = M('Category')->getField('cid,name');
        
        foreach ($list as $k=>$v){
        	$list[$k]['category'] = $categorylist[$v['cid']];
        }
        
		$this->assign('list', $list);
		
		$this->display();
	}
	
	public function info(){
		$where['id'] = $this->_get('id');
		$where['status'] = 1;
		
		M('News')->where($where)->setInc('views'); // 浏览量+1
		
		$info = M('News')->where($where)->find();
		
		if (!$info)$this->error('信息不存在...');
		
		$categoryname = M('Category')->where('id='.$info['cid'].'')->find();
		
		$info['category'] = M('Category')->where('cid='.$info['cid'].'')->find();
		
		
		$this->assign('info', $info);
		
		$this->display();
	}
	
	public function about(){
		$this->display();
	}
	
	public function contact(){
		$this->display();
	}
	
	public function rss(){
		$Newslist = M('News')->where('status=1')->order('id desc')->select();
		import("ORG.Net.Rss");
		$systemConfig = include WEB_ROOT . 'Common/systemConfig.php';
		$RSS = new RSS($systemConfig['SITE_INFO']['name'],$systemConfig['WEB_ROOT'].'index.html',$systemConfig['SITE_INFO']['description']);
		foreach($Newslist as $list){
			$RSS->AddItem($list['title'],U('/news/'.$list['id']),$list['description'],date('Y-m-d H:i:s',$list['published']));
		}
		
		$RSS->Display();
	}
}