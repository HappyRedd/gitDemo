﻿jQuery.easing['jswing'] = jQuery.easing['swing'];
jQuery.extend( jQuery.easing,
{
	def: 'easeOutQuad',
	swing: function (x, t, b, c, d) {
		return jQuery.easing[jQuery.easing.def](x, t, b, c, d);
	},
	easeInQuad: function (x, t, b, c, d) {
		return c*(t/=d)*t + b;
	},
	easeOutQuad: function (x, t, b, c, d) {
		return -c *(t/=d)*(t-2) + b;
	},
	easeOutBounce: function (x, t, b, c, d) {
		if ((t/=d) < (1/2.75)) {
			return c*(7.5625*t*t) + b;
		} else if (t < (2/2.75)) {
			return c*(7.5625*(t-=(1.5/2.75))*t + .75) + b;
		} else if (t < (2.5/2.75)) {
			return c*(7.5625*(t-=(2.25/2.75))*t + .9375) + b;
		} else {
			return c*(7.5625*(t-=(2.625/2.75))*t + .984375) + b;
		}
	}
});
var mynav={
	buildnav:function($, setting){
		var $navobj=$("#"+setting.navid+">ul")
		$navobj.parent().get(0).className=setting.classname || "nav"
		var $parentobj=$navobj.find("ul").parent()
		$parentobj.hover(
			function(e){ $(this).children('a:eq(0)').addClass('on') },
			function(e){ $(this).children('a:eq(0)').removeClass('on') }
		)
		$parentobj.each(function(i){
			var $obj=$(this).css({zIndex: 999-i})
			var $subul=$(this).children('ul:eq(0)')
			this.datas={w:this.offsetWidth, h:this.offsetHeight,ulw:$subul.width(), ulh:$subul.height()}
			this.istop =$obj.parents("ul").length==1? true : false
			$subul.css({top:this.istop && setting.orientation!='v'? this.datas.h+"px" : 0})
			$obj.hover(function(e){
				var $playobj=$(this).children("ul:eq(0)")
				this._offsets={left:$(this).offset().left, top:$(this).offset().top}
				var mleft=this.istop && setting.orientation!='v'? 0 : this.datas.ulw
				mleft=(this._offsets.left+mleft+this.datas.ulw>$(window).width())? (this.istop && setting.orientation!='v'? -this.datas.ulw+this.datas.w : -this.datas.w) : mleft 
				$playobj.css({left:mleft+"px", width:this.datas.ulw+'px'})
				$playobj.stop(true, true).slideDown({duration:600, easing:"easeOutBounce"});

			},function(e){
				$(this).children("ul:eq(0)").stop(true, true).fadeOut();
			})
		});
		$navobj.find("ul").css({display:'none', visibility:'visible'})
	},

	init:function(setting){	
		jQuery(document).ready(function($){
			mynav.buildnav($, setting)
		})
	}
}

/**
 * jquery特效http://www.51xuediannao.com/js/
 * @param	{String}	图片路径
 * @param	{Function}	尺寸就绪
 * @param	{Function}	加载完毕 (可选)
 * @param	{Function}	加载错误 (可选)
 * @example imgReady('http://www.google.com.hk/intl/zh-CN/images/logo_cn.png', function () {
		alert('size ready: width=' + this.width + '; height=' + this.height);
	});
 */
var imgReady = (function () {
	var list = [], intervalId = null,

	// 用来执行队列
	tick = function () {
		var i = 0;
		for (; i < list.length; i++) {
			list[i].end ? list.splice(i--, 1) : list[i]();
		};
		!list.length && stop();
	},

	// 停止所有定时器队列
	stop = function () {
		clearInterval(intervalId);
		intervalId = null;
	};

	return function (url, ready, load, error) {
		var onready, width, height, newWidth, newHeight,
			img = new Image();
		
		img.src = url;

		// 如果图片被缓存，则直接返回缓存数据  <a href="http://www.51xuediannao.com/js/">jquery特效</a> http://www.51xuediannao.com/js/
		if (img.complete) {
			ready.call(img);
			load && load.call(img);
			return;
		};
		
		width = img.width;
		height = img.height;
		
		// 加载错误后的事件
		img.onerror = function () {
			error && error.call(img);
			onready.end = true;
			img = img.onload = img.onerror = null;
		};
		
		// 图片尺寸就绪
		onready = function () {
			newWidth = img.width;
			newHeight = img.height;
			if (newWidth !== width || newHeight !== height ||
				// 如果图片已经在其他地方加载可使用面积检测
				newWidth * newHeight > 1024
			) {
				ready.call(img);
				onready.end = true;
			};
		};
		onready();
		
		// 完全加载完毕的事件
		img.onload = function () {
			// onload在定时器时间差范围内可能比onready快
			// 这里进行检查并保证onready优先执行
			!onready.end && onready();
		
			load && load.call(img);
			
			// IE gif动画会循环执行onload，置空onload即可
			img = img.onload = img.onerror = null;
		};

		// 加入队列中定期执行
		if (!onready.end) {
			list.push(onready);
			// 无论何时只允许出现一个定时器，减少浏览器性能损耗
			if (intervalId === null) intervalId = setInterval(tick, 40);
		};
	};
})();

//返回顶部
$(function(){
		$('.top').click(function(){
			$('html,body').animate({'scrollTop':'0px'});
			return false;
		});
		$(window).bind("scroll",function(){
			if($(document).scrollTop() > 0){
				$('.top').fadeIn();
				if ($.browser.msie && ($.browser.version == "6.0") && !$.support.style) {
					$('.top').css({top:$(window).height() + $(document).scrollTop() - $(window).height()/2});
				};
			}else{
				$('.top').fadeOut();
			}
		});
});